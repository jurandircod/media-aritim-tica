package Entidade;
import java.util.Scanner;

public class Calculadora {
    public double constanteCircunferencia = 2;
    public double constanteVolume = 4;
    public static double pi = 3.1416;
    double raio = ler();
    public double ler() {
        Scanner ler = new Scanner(System.in);
        System.out.println("digite um numero que sera o valor de raio");
        double raio = ler.nextDouble();
        return raio;
    }

    public double calculandoCircunferencia() {
        double resultadoCircunferencia = constanteCircunferencia * pi * raio;
        return resultadoCircunferencia;
    }

    public double calculaVolume() {
        double resultadoVolume = constanteVolume * pi * (raio * raio * raio) / 3;
        return resultadoVolume;
    }
}

