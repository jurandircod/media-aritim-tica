import Entidade.Calculadora;
public class Main {
    public static void main(String[] args) {
        Calculadora objcalc = new Calculadora();

        objcalc.calculandoCircunferencia();
        System.out.printf(" o valor da circunferência é " + objcalc.calculandoCircunferencia());

        objcalc.calculaVolume();
        System.out.printf(" o valor do volume é " + objcalc.calculaVolume());

    }
}